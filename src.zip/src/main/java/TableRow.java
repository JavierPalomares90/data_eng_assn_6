public class TableRow {
	public  Integer theKey;
	public Integer columnA;
	public Integer columnB;
	public String filler;

}
